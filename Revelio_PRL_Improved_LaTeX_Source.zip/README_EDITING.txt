Revelio PRL Final Report - Editable LaTeX Source
================================================

Main file to edit:
  main.tex

Compile with:
  pdflatex main.tex
  pdflatex main.tex

Important folders:
  figures/      Main report figures in PDF and PNG format.
  tables/       LaTeX and CSV result tables.
  screenshots/  Appendix screenshots only.
  logs/         Raw selected training logs.
  jobs/         SLURM job scripts used for the final selected runs.

Recommended editing:
  - Use the PDF figures in figures/ for the main report.
  - Use screenshots only in the appendix or delete the appendix if the report must be shorter.
  - If the professor wants exactly 10 pages, keep Sections 1-8 and comment out the Appendix.
  - The final numerical values are in tables/final_values_for_report.csv.
